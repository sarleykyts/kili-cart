# KiliCart Mobile App

Flutter mobile app (iOS & Android) for the KiliCart full-stack wishlist & flash-sale tracker.

## Tech Stack
- Flutter (Dart) - cross-platform iOS & Android
- Provider - state management
- Hive - local offline-first database
- SharedPreferences - user/session storage
- Firebase Core + Messaging - FCM push notifications
- flutter_local_notifications - local notifications
- http - REST API client
- share_plus - share product links
- url_launcher - open Kilimall links
- google_fonts - Poppins typography
- intl - date formatting

## Project Structure
```
kilicart_app/
  lib/
    main.dart              - App entry + routing
    firebase_options.dart  - Firebase config
    core/
      theme/
        app_colors.dart    - Design system colors (#FF6B00)
        app_theme.dart     - AMOLED & Vintage themes
        theme_provider.dart- Theme persistence
      widgets/
        kilicart_logo.dart - Cart + lightning logo
        liquid_glass_button.dart - Frosted glass buttons
        product_card.dart  - Product card w/ long-press
        collection_card.dart - Collection card
        floating_bottom_nav.dart - Pill nav + FAB
      services/
        api_service.dart   - REST client
        local_storage.dart - Hive offline storage
        notification_service.dart - FCM + local notifications
        share_service.dart - Share intents
        haptic_service.dart - Haptics
        config/
          app_config.dart  - API base URL
    models/
      product.dart         - Hive model
      collection.dart      - Hive model (6 defaults)
      user.dart            - User model
    providers/
      app_provider.dart    - State + sync logic
    screens/
      home_screen.dart     - Home (exact reference design)
      collections_screen.dart
      settings_screen.dart
      product_detail_screen.dart
      add_product_screen.dart
      add_collection_screen.dart
      onboarding_screen.dart
  android/
    app/src/main/AndroidManifest.xml - Share Intent + permissions
```

## Design System
- Primary: Vivid Orange `#FF6B00`
- Two themes: AMOLED Black (`#000000`) & Vintage (cream `#FDF6EC`)
- Liquid glass / frosted glass buttons
- KiliCart logo (cart + ⚡) top-left on every card
- Floating pill bottom nav: Home / Collections / Settings + orange `+`

## Setup

### Prerequisites
- Flutter SDK >= 3.2
- Android Studio / Xcode
- Backend running (see `../backend`)

### Install
```bash
cd kilicart_app
flutter pub get
```

### Configure Firebase
1. Create a Firebase project
2. Add Android app (package: `com.kilicart.app`)
3. Download `google-services.json` to `android/app/`
4. Update `lib/firebase_options.dart` with your config
5. Enable Cloud Messaging

### Run
```bash
flutter run
```

### Build APK
```bash
flutter build apk --release
```

## Features
- [x] Home screen matching reference design (greeting, stats, LIVE FLASH SALE countdown, curated products)
- [x] Floating liquid-glass bottom nav (Home/Collections/Settings + orange +)
- [x] Collections: Shoes, Clothes, Luxury, Bedroom, Kitchen, Bathroom + CRUD
- [x] Product cards with KiliCart logo top-left, discount badge, FLASH tag
- [x] Long-press menu: Copy Link + Delete
- [x] Product detail, add product, target price alerts
- [x] Share Intent (Android) for Kilimall links
- [x] Both themes (AMOLED Black & Vintage) with live toggle
- [x] Offline-first (Hive local storage)
- [x] FCM + local notifications
- [x] Haptic feedback
- [x] Onboarding screens
- [x] User auth (anonymous + email/password via backend)
- [x] Export/Import wishlist (backend)
